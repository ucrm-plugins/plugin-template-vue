<?php
declare(strict_types=1);

// NOTE: Perform any additional "bootstrapping" specific to UCRM v3.0.0-beta.10 here...


echo UCRM_VERSION;
echo UCRM_VERSION_STABILITY;
